package reserva.reserva.excepciones;

public class ConfirmacionReservaException extends RuntimeException {
   public ConfirmacionReservaException(String mensaje) {
        super(mensaje);
    }
}
