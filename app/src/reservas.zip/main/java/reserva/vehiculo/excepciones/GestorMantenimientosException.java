package reserva.vehiculo.excepciones;

public class GestorMantenimientosException extends RuntimeException {
    public GestorMantenimientosException() { super(); }
    public GestorMantenimientosException(String message) { super(message); }
}

