package reserva.vehiculo;

import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.Test;

import reserva.cliente.*;
import reserva.modalidad.*;
import reserva.reserva.*;

public class GestorReservasMantenimientoIntegrationTest {
    //CHEQUEAR
    @Test
    public void finalizarReserva_abreMantenimiento_exitoso() {
        GestorReservas gestorReservas = new GestorReservas();
        // suponemos que GestorReservas internamente contiene o referencia a GestorMantenimientos
        Vehiculo v = new Vehiculo("RV01", "Marca", "Modelo", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("5000"));
        Cliente c = new ClienteParticular("Test", "Calle", "111", "t@t.com", "000");
        ModalidadAlquiler modalidad = new PorDia(); // o la implementación que tengas
        Reserva r = new Reserva("R-100", v, c, LocalDate.now(), LocalDate.now().plusDays(2), modalidad);

        gestorReservas.registrarReserva(r);
        gestorReservas.confirmarReserva("R-100");

        // usamos la firma extendida: finalizarReserva(codigoReserva, requiereMantenimiento, descripcion)
        gestorReservas.finalizarReserva("R-100", true, "Revisión post-uso");

        // obtenemos el gestor de mantenimientos (si tu GestorReservas lo expone)
        GestorMantenimientos gm = gestorReservas.getGestorMantenimientos();
        assertNotNull("Debe existir el gestor de mantenimientos", gm);

        // Debe existir al menos un mantenimiento asociado al vehículo
        assertFalse("Debe haber mantenimientos registrados", gm.getMantenimientosDeVehiculo(v).isEmpty());

        Mantenimiento m = gm.getMantenimientosDeVehiculo(v).get(0);
        assertTrue("El mantenimiento debe estar abierto tras finalizar reserva", m.isAbierto());
        assertEquals("El vehículo debe estar en estado MANTENIMIENTO", EstadoVehiculo.Estado.MANTENIMIENTO, v.getEstado());
    }
}

