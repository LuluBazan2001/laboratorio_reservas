package reserva.vehiculo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import reserva.vehiculo.excepciones.GestorMantenimientosException;
import reserva.vehiculo.excepciones.MantenimientoNoEncontradoException;

//Aqui vamos a gestionar todos los mantenimientos abiertos y cerrados, reportes y bloqueos
public class GestorMantenimientos {

    private List<Mantenimiento> mantenimientos = new ArrayList<>();

    public Mantenimiento abrirMantenimiento(Vehiculo vehiculo, LocalDate fecha, String descripcion) {
        if (vehiculo.getEstado() == EstadoVehiculo.Estado.RENTADO)
            throw new MantenimientoNoEncontradoException("No se puede realizar mantenimiento a un vehículo rentado");

        Mantenimiento m = new Mantenimiento(vehiculo, fecha, descripcion);
        mantenimientos.add(m);
        return m;
    }

    public void cerrarMantenimiento(Mantenimiento mantenimiento, LocalDate fechaCierre, String trabajo, BigDecimal costo) {
        if (mantenimiento == null)
            throw new GestorMantenimientosException("El mantenimiento no puede ser nulo");
        mantenimiento.cerrar(fechaCierre, trabajo, costo);
    }

    public List<Mantenimiento> getMantenimientos() {
        return Collections.unmodifiableList(mantenimientos);
    }

    public List<Mantenimiento> getMantenimientosAbiertos() {
        return mantenimientos.stream().filter(Mantenimiento::isAbierto).toList();
    }

    public List<Mantenimiento> getMantenimientosDeVehiculo(Vehiculo vehiculo) {
        return mantenimientos.stream().filter(m -> m.getVehiculo().equals(vehiculo)).toList();
    }

    public BigDecimal calcularCostoTotalEntre(LocalDate desde, LocalDate hasta) {
        return mantenimientos.stream()
                .filter(m -> m.isCerrado()
                        && !m.getFechaCierre().isBefore(desde)
                        && !m.getFechaCierre().isAfter(hasta))
                .map(Mantenimiento::getCosto)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}

