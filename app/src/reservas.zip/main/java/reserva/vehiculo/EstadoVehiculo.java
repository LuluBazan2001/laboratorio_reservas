package reserva.vehiculo;

public class EstadoVehiculo {
    public enum Estado {
        DISPONIBLE,
        RENTADO,
        MANTENIMIENTO
    }
}
