package reserva.reserva;
import org.junit.Test;

import reserva.vehiculo.*;
import reserva.cliente.*;
import reserva.modalidad.ModalidadAlquiler;
import reserva.modalidad.PorDia;
import reserva.reserva.excepciones.*;

import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class ReservaTest {

    /*************************************************************************************************** */
    /*                                 CONFIRMAR RESERVA                                                 */
    /*************************************************************************************************** */
    @Test
    public void testConfirmarReserva_Exitosa() {
        Vehiculo vehic = new Vehiculo("ABC123", "Toyota", "Corolla", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("Juan", "Calle 123", "381111111", "juan@gmail.com", "40111222");
        ModalidadAlquiler modalidad = new PorDia();
        Reserva reserva = new Reserva("R001", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(3), modalidad);

        reserva.confirmarReserva();

        assertEquals("El estado de la reserva debe cambiar a ACTIVA", EstadoReserva.ACTIVA, reserva.getEstado());
        assertEquals("El vehículo debe quedar RENTADO al confirmar la reserva", EstadoVehiculo.Estado.RENTADO, vehic.getEstado());
    }

    @Test(expected = ConfirmacionReservaException.class)
    public void testConfirmarReserva_LanzaExceptionSiNoPendiente() {
        Vehiculo vehic = new Vehiculo("DEF456", "Renault", "Clio", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("Ana", "Mitre 456", "381222222", "ana@gmail.com", "40555111");
        ModalidadAlquiler modalidad = new PorDia();
        Reserva reserva = new Reserva("R002", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(2), modalidad);

        // Primero se confirma correctamente
        reserva.confirmarReserva();
        // Luego intenta confirmarse otra vez (ya no está pendiente)
        reserva.confirmarReserva(); // Debe lanzar ConfirmacionReservaException
    }

    /*************************************************************************************************** */
    /*                                 CANCELAR RESERVA                                                  */
    /*************************************************************************************************** */
    @Test
    public void testCancelarReserva_Exitosa() {
        Vehiculo vehic = new Vehiculo("GHI789", "Ford", "Focus", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("Pedro", "Belgrano 300", "381333333", "pedro@gmail.com", "40666333");
        ModalidadAlquiler modalidad = new PorDia();
        Reserva reserva = new Reserva("R003", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(4), modalidad);

        reserva.cancelarReserva();

        assertEquals("El estado de la reserva debe ser CANCELADA", EstadoReserva.CANCELADA, reserva.getEstado());
        assertEquals("El vehículo debe quedar DISPONIBLE al cancelar la reserva", EstadoVehiculo.Estado.DISPONIBLE, vehic.getEstado());
    }

    @Test(expected = CancelarReservasException.class)
    public void testCancelarReserva_LanzaExceptionSiFinalizada() {
        Vehiculo vehic = new Vehiculo("JKL321", "Peugeot", "208", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("Sofía", "Catamarca 12", "381444444", "sofia@gmail.com", "40999111");
        ModalidadAlquiler modalidad = new PorDia();
        Reserva reserva = new Reserva("R004", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(1), modalidad);

        reserva.confirmarReserva();
        reserva.finalizarReserva(); // Ahora está finalizada
        reserva.cancelarReserva();  // Debe lanzar excepción
    }

    /*************************************************************************************************** */
    /*                                 FINALIZAR RESERVA                                                 */
    /*************************************************************************************************** */
    @Test
    public void testFinalizarReserva_Exitosa() {
        Vehiculo vehic = new Vehiculo("MNO654", "Chevrolet", "Onix", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("María", "Buenos Aires 100", "381555555", "maria@gmail.com", "41111000");
        ModalidadAlquiler modalidad = new PorDia();
        Reserva reserva = new Reserva("R005", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(5), modalidad);

        reserva.confirmarReserva();  // Debe estar activa
        reserva.finalizarReserva();

        assertEquals("El estado de la reserva debe ser FINALIZADA", EstadoReserva.FINALIZADA, reserva.getEstado());
        assertEquals("El vehículo debe volver a estar DISPONIBLE al finalizar la reserva", EstadoVehiculo.Estado.DISPONIBLE, vehic.getEstado());
    }

    @Test(expected = FinalizarReservasException.class)
    public void testFinalizarReserva_LanzaExceptionSiNoActiva() {
        Vehiculo vehic = new Vehiculo("PQR987", "Honda", "Civic", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("Diego", "San Martín 77", "381666666", "diego@gmail.com", "42222333");
        ModalidadAlquiler modalidad = new PorDia();
        Reserva reserva = new Reserva("R006", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(2), modalidad);

        // No se confirma antes
        reserva.finalizarReserva(); // Debe lanzar FinalizarReservasException
    }

    /*************************************************************************************************** */
    /*                                 COSTO TOTAL (comportamiento base)                                 */
    /*************************************************************************************************** */
    @Test
    public void testCalcularCostoTotal_SinPromosNiExtras() {
        Vehiculo vehic = new Vehiculo("PQR987", "Honda", "Civic", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("9000"));
        Cliente cliente = new ClienteParticular("Diego", "San Martín 77", "381666666", "diego@gmail.com", "42222333");

        ModalidadAlquiler modalidad = new PorDia();

        Reserva reserva = new Reserva("R006", vehic, cliente, LocalDate.now(), LocalDate.now().plusDays(2), modalidad);

        BigDecimal costoTotal = reserva.getCostoTotal();

        assertEquals(new BigDecimal("27000"), costoTotal);
    }

}
