package reserva.vehiculo;

import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.Test;
import reserva.vehiculo.excepciones.MantenimientoInvalidoException;

public class MantenimientoTest {
    //CHEQUEAR
    @Test
    public void abrirYCerrarMantenimiento_exitoso() {
        Vehiculo v = new Vehiculo("TEST01", "Marca", "Modelo", EstadoVehiculo.Estado.DISPONIBLE, TipoVehiculo.AUTO, new BigDecimal("1000"));
                                                //Apertura
        Mantenimiento m = new Mantenimiento(v, LocalDate.now(), "Chequeo post-uso");

        // al crear (según la implementación propuesta) el vehículo debe quedar en estado MANTENIMIENTO
        assertTrue("El mantenimiento debe estar abierto inicialmente", m.isAbierto());
        assertEquals("Vehículo debe quedar en mantenimiento", EstadoVehiculo.Estado.MANTENIMIENTO, v.getEstado());

        // cerrar mantenimiento
        BigDecimal costo = new BigDecimal("1500");
        m.cerrar(LocalDate.now().plusDays(3), "Cambio de pastillas", costo);

        assertFalse("Ahora debe estar cerrado", m.isAbierto());
        assertEquals(costo, m.getCosto());
        assertEquals("Cambio de pastillas", m.getTrabajoRealizado());
        assertEquals("Vehículo liberado a DISPONIBLE", EstadoVehiculo.Estado.DISPONIBLE, v.getEstado());
    }

    // Test que falla (activo) para validar argumento nulo — usa excepción personalizada
    @Test(expected = MantenimientoInvalidoException.class)
    public void abrirMantenimiento_conVehiculoNulo_debeFallar() {
        new Mantenimiento(null, LocalDate.now(), "desc");
    }
}


