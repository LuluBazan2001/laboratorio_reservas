package reserva.modalidad.excepciones;

public class VehiculoOTarifaNulaException extends RuntimeException {
   public VehiculoOTarifaNulaException(String mensaje) {
        super(mensaje);
    }
}
