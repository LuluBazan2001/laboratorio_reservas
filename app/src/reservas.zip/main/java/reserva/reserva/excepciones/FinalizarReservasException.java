package reserva.reserva.excepciones;

public class FinalizarReservasException extends RuntimeException {
   public FinalizarReservasException(String mensaje) {
        super(mensaje);
    }
}
